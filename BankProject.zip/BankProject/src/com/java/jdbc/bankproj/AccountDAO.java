package com.java.jdbc.bankproj;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountDAO {

	Connection con;
	PreparedStatement pst;
	
	public Account searchAccount(int accountNo) {
		Account account = null;
		con = ConnectionHelper.getConnection();
		String cmd = "select * from Account where accountNo=?";
		try {
			pst = con.prepareStatement(cmd);
			pst.setInt(1, accountNo);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				account = new Account();
				account.setAccountNo(rs.getInt("accountNo"));
				account.setFirstName(rs.getString("firstName"));
				account.setLastName(rs.getString("lastName"));
				account.setCity(rs.getString("city"));
				account.setState(rs.getString("State"));
				account.setAmount(rs.getInt("amount"));
				account.setCheqFacil(rs.getString("cheqFacil"));
				account.setAccountType(rs.getString("accountType"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}
	public String createAccount(Account account) throws SQLException {
		con = ConnectionHelper.getConnection();
		String cmd = "insert into Account(accountNo,FirstName,LastName,City,state, "
				+ "amount,cheqFacil,AccountType) values(?,?,?,?,?,?,?,?)";
		pst = con.prepareStatement(cmd);
		pst.setInt(1, account.getAccountNo());
		pst.setString(2, account.getFirstName());
		pst.setString(3, account.getLastName());
		pst.setString(4, account.getCity());
		pst.setString(5, account.getState());
		pst.setInt(6, account.getAmount());
		pst.setString(7, account.getCheqFacil());
		pst.setString(8, account.getAccountType());
		pst.executeUpdate();
		return "Account Created Successfully...";
	}
	public int generateAccountNo() throws SQLException {
		con = ConnectionHelper.getConnection();
		String cmd = "select case when max(accountNo) is NULL then 1 "
				+ " else max(accountNo)+1 end accno from Account";
		pst = con.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int accNo=rs.getInt("accno");
		return accNo;
	}
}
